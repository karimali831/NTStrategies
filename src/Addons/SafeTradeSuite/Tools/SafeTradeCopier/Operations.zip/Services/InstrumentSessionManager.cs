﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;

namespace NinjaTrader.NinjaScript.AddOns.SafeTradeSuite.Tools.SafeTradeCopier
{
    public partial class SafeTradeCopierTool
    {
        private readonly List<InstrumentSession> _instrumentSessions = new List<InstrumentSession>();
        private InstrumentSession _activeInstrumentSession;
        private bool _suppressSessionUiEvents;
        
        private string GetSelectedInstrumentName()
        {
            return (_instrumentSelector?.SelectedItem as string ?? "").Trim();
        }

        private Instrument GetInstrument()
        {
            var instrName = GetSelectedInstrumentName();
            return string.IsNullOrWhiteSpace(instrName) ? null : Instrument.GetInstrument(instrName);
        }
        
        private string GetInstrumentFullName()
        {
            var instr = GetInstrument();
            return instr?.FullName ?? "";
        }
        
        private void EnsureInitialInstrumentSession()
        {
            if (_instrumentSessions.Count > 0)
                return;

            var firstInstrument = GetAvailableInstruments().FirstOrDefault() ?? "";

            if (string.IsNullOrWhiteSpace(firstInstrument))
                LogStatus("No active instruments detected during initial session setup.");

            var session = new InstrumentSession
            {
                InstrumentName = firstInstrument
            };

            _instrumentSessions.Add(session);
            _activeInstrumentSession = session;
        }

        private List<string> GetAvailableInstruments()
        {
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            AddSessionInstruments(names);
            AddPositionInstruments(names);
            AddCurrentSelectedInstrument(names);
            AddChartWindowInstruments(names);

            var result = names
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .OrderBy(x => x)
                .ToList();

            _engine?.Log(result.Count == 0
                ? "Available instruments: <none found>"
                : "Available instruments: " + string.Join(", ", result));

            return result;
        }

        private void RefreshInstrumentSelectorItems()
        {
            if (_instrumentSelector == null) return;

            var selected = _instrumentSelector.SelectedItem as string;
            var items = GetAvailableInstruments();

            if (items.Count == 0)
                LogStatus("No active instruments detected. Open a chart or select an instrument session.");

            _instrumentSelector.ItemsSource = null;
            _instrumentSelector.Items.Clear();

            foreach (var item in items)
                _instrumentSelector.Items.Add(item);

            if (!string.IsNullOrWhiteSpace(selected) && _instrumentSelector.Items.Contains(selected))
                _instrumentSelector.SelectedItem = selected;
            else if (_instrumentSelector.Items.Count > 0)
                _instrumentSelector.SelectedIndex = 0;
        }

        private void AddInstrumentSession(string instrumentName)
        {
            SaveUiToActiveSession();

            var session = new InstrumentSession
            {
                InstrumentName = instrumentName,
                MasterAccount = _masterBox?.SelectedItem as Account,
                MasterQty = ParseQtyOrDefault(_masterQtyBox?.Text, 1),
                MasterAtm = (_masterAtmBox?.SelectedItem as string) ?? "None"
            };

            _instrumentSessions.Add(session);
            _activeInstrumentSession = session;

            RefreshInstrumentTabs();
            LoadActiveSessionToUi();
        }

        private void SwitchToSession(InstrumentSession session)
        {
            if (session == null) return;
            if (ReferenceEquals(_activeInstrumentSession, session)) return;

            SaveUiToActiveSession();
            _activeInstrumentSession = session;
            LoadActiveSessionToUi();
        }
        
        private void AddSessionInstruments(HashSet<string> names)
        {
            foreach (var s in _instrumentSessions)
            {
                var n = (s?.InstrumentName ?? "").Trim();
                if (!string.IsNullOrWhiteSpace(n))
                    names.Add(n);
            }
        }

        private static void AddPositionInstruments(HashSet<string> names)
        {
            foreach (var acc in Account.All)
            {
                if (acc?.Positions == null)
                    continue;

                foreach (var p in acc.Positions)
                {
                    var n = p?.Instrument?.FullName ?? "";
                    if (!string.IsNullOrWhiteSpace(n))
                        names.Add(n);
                }
            }
        }

        private void AddCurrentSelectedInstrument(HashSet<string> names)
        {
            var current = (_instrumentSelector?.SelectedItem as string ?? "").Trim();
            if (!string.IsNullOrWhiteSpace(current))
                names.Add(current);

            var active = (_activeInstrumentSession?.InstrumentName ?? "").Trim();
            if (!string.IsNullOrWhiteSpace(active))
                names.Add(active);
        }
        
        private void AddChartWindowInstruments(HashSet<string> names)
        {
            if (names == null)
                return;

            var dispatcher = _uiDispatcher ?? _window?.Dispatcher ?? Application.Current?.Dispatcher;
            if (dispatcher == null)
                return;

            try
            {
                if (dispatcher.CheckAccess())
                {
                    AddChartWindowInstrumentsOnUiThread(names);
                }
                else
                {
                    dispatcher.Invoke(() => AddChartWindowInstrumentsOnUiThread(names));
                }
            }
            catch (Exception ex)
            {
                _engine?.Log("AddChartWindowInstruments failed: " + ex.Message);
            }
        }
        
        private void AddChartWindowInstrumentsOnUiThread(HashSet<string> names)
        {
            var windows = Application.Current?.Windows;
            if (windows == null)
            {
                LogStatus("Chart scan: Application.Current.Windows is null.");
                return;
            }

            LogStatus("Chart scan: window count = " + windows.Count);

            foreach (Window win in windows)
            {
                if (win == null)
                    continue;

                var title = "";
                try
                {
                    title = win.Title ?? "";
                }
                catch
                {
                }

                LogStatus("Chart scan window: " + (string.IsNullOrWhiteSpace(title) ? "<no title>" : title));

                TryAddChartInstrumentsFromVisual(win, names);
            }
        }
        
        private void TryAddChartInstrumentsFromVisual(DependencyObject root, HashSet<string> names)
        {
            if (root == null || names == null)
                return;

            TryAddInstrumentFromObject(root, names);

            var count = VisualTreeHelper.GetChildrenCount(root);
            for (var i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(root, i);
                TryAddChartInstrumentsFromVisual(child, names);
            }
        }
        
        private void TryAddInstrumentFromObject(object obj, HashSet<string> names)
        {
            if (obj == null || names == null)
                return;
            
            // 1) Direct public Instrument property
            var instrumentProp = obj.GetType().GetProperty("Instrument");
            if (instrumentProp != null)
            {
                var instrumentValue = instrumentProp.GetValue(obj, null);
                if (instrumentValue is Instrument instr && !string.IsNullOrWhiteSpace(instr.FullName))
                {
                    names.Add(instr.FullName);
                    return;
                }
            }

            // 2) Common WPF header/content text sources
            if (obj is TabItem tabItem)
            {
                TryAddInstrumentFromCandidate(tabItem.Header, names);
                return;
            }

            if (obj is HeaderedContentControl headered)
            {
                TryAddInstrumentFromCandidate(headered.Header, names);
                return;
            }

            if (obj is TextBlock tb)
            {
                TryAddInstrumentFromCandidate(tb.Text, names);
                return;
            }

            if (obj is ContentControl cc)
            {
                TryAddInstrumentFromCandidate(cc.Content, names);
            }
        }

        private void TryAddInstrumentFromCandidate(object candidate, HashSet<string> names)
        {
            if (candidate == null || names == null)
                return;

            if (candidate is Instrument instr)
            {
                if (!string.IsNullOrWhiteSpace(instr.FullName))
                {
                    names.Add(instr.FullName);
                    LogStatus("Instrument found directly: " + instr.FullName);
                }
                return;
            }

            var text = candidate as string;
            if (string.IsNullOrWhiteSpace(text))
                return;

            text = text.Trim();
            
            var resolved = Instrument.GetInstrument(text);
            if (resolved != null && !string.IsNullOrWhiteSpace(resolved.FullName))
            {
                names.Add(resolved.FullName);
                LogStatus($"Instrument resolved from text '{text}' -> {resolved.FullName}");
            }
        }
        
        private void LogStatus(string message)
        {
            _engine?.Log(message);
        }
    }
}